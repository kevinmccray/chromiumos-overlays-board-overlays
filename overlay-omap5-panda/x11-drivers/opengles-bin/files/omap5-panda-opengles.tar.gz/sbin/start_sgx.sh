#!/bin/sh

# Inherited from int3/zebu.
devmem2 0x4A009200 w 2
devmem2 0x4A009220 w 2
devmem2 0x56004004 w 0x55
# Enable IRQ.
# OCP_DEBUG_CONFIG <- THALIA_INT_BYPASS_MASK
devmem2 0x5600ff08 w 0x80000000

pvrsrvinit
